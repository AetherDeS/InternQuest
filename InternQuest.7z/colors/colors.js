export const darkTheme = {
    primary: "#343F3E",
    secondary: "#505A5B",
    accentLight: "#CCFCCB",
    accentContrast: "#D2F898",
    white: "#F1FFFA"
  };
export const ayuDark = {
    primary1: "#29272B",
    primary2: "#38373C",
    accent1: "#F5C89B",
    accent_gr1: "#F5C89B",
    accent_gr2: "#EDC6A0"
  };
