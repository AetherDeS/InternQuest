module.exports = {
    assets: ['./assets/Comfortaa.ttf'],
  };
  