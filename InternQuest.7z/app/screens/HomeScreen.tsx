import React from 'react';
import { ScrollView, View, Text, TextProps } from 'react-native';
import { Form } from "@/app/components/FormNews";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HeaderAppTitle from '../components/HeaderLogo';
import { ThemedText } from '../components/ThemedText';
import JobContainer from '../components/JobContainer';

// Цвета
import {ayuDark} from "../../colors/colors";
const { primary1, primary2, accent1, accent_gr1, accent_gr2 } = ayuDark;

const Tab = createBottomTabNavigator();

export default function HomeScreen() {
  return (
    <View style={{ width: '100%', height: '100%', backgroundColor: '#29272B' }}>
      <HeaderAppTitle />
      <ScrollView>
        <JobContainer
          jobTitle="Администратор базы данных поликлиники"
          jobPrice="2 000₽ неделю"
          jobOrg="ООО Поликлиника"
          jobGeo="Р-н Перово" />
        <ThemedText type='default'></ThemedText>
      </ScrollView>
    </View>
  );
}