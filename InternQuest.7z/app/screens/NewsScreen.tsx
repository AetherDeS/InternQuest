import React from 'react';
import { View } from 'react-native';
import { Form } from "@/app/components/FormNews";
import HeaderAppTitle from '../components/HeaderLogo';

// Цвета
import { ayuDark } from "../../colors/colors";
const { primary1, primary2, accent1, accent_gr1, accent_gr2 } = ayuDark;

export default function NewsScreen() {
  return (
        <View style={{backgroundColor: primary1, height: '100%'}}>  
          <HeaderAppTitle/>
        </View>
  );
}