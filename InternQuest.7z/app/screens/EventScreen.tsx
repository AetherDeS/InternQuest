import React from 'react';
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';
import MasonryList from '@react-native-seoul/masonry-list';
import HeaderLogo from '../components/HeaderLogo';

// Цвета
import { ayuDark } from "../../colors/colors";
const { primary1, primary2, accent1, accent_gr1, accent_gr2 } = ayuDark;

type Item = {
  id: string;
  image: string;
  date: string;
  description: string;
}

// DATABASE
const mysql = require('mysql');
const connection = mysql.createConnection({
  host: '77.239.115.153',
  user: 'pahan',
  password: 'pahan',
  database: 'internquest'
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL server:', err);
    return;
  }
  console.log('Connected to MySQL server!');
})

connection.query('select date, description from news', (err, results) =>{
  if (err) { 
    console.error('Error executing MySQL query:', err); 
    return; 
  } 
  console.log('Query results:', results);
});

connection.end((err) => { 
  if (err) { 
    console.error('Error closing MySQL connection:', err); 
    return; 
  } 
  console.log('MySQL connection closed!'); 
});

// Наш массив с ивентами | из базы ( в будущем)
var DATA: Item[] = [
  { id: '1', date: '14.02 - 28.02', description: 'Встреча с выпускниками N колледжа. Их история успеха',image: 'https://i.pinimg.com/736x/b4/2c/93/b42c93bd23c1e967ff97a8b9d012134b.jpg' },
  { id: '2', date: '14.02 - 28.02', description: 'Как программировать и не выгореть',image: 'https://i.pinimg.com/736x/b4/2c/93/b42c93bd23c1e967ff97a8b9d012134b.jpg' },
  { id: '3', date: '14.02 - 28.02', description: 'Мастер класс по тайм менеджменту',image: 'https://i.pinimg.com/736x/b4/2c/93/b42c93bd23c1e967ff97a8b9d012134b.jpg' },
  { id: '4', date: '14.02 - 28.02', description: 'Как успевать всё. Что такое Кайдзен?',image: 'https://i.pinimg.com/736x/b4/2c/93/b42c93bd23c1e967ff97a8b9d012134b.jpg' },
  // Добавьте больше элементов
];


const App = () => {
  const renderItem = ({ item }) => (
    <View style={[styles.item]}>
      <Image source={{ uri: item.image }} style={styles.image} />
      <Text style={styles.date}>{item.date}</Text>
      <Text style={styles.description}>{item.description}</Text>
    </View>
  );

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <HeaderLogo/>
      <MasonryList
        data={DATA}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        numColumns={2} // Количество колонок
        contentContainerStyle={styles.masonryContainer}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    padding: 10,
    paddingTop: 0,
    backgroundColor: primary1,
  },
  masonryContainer: {
    paddingBottom: 40, 
  },
  item: {
    padding: 5,
    paddingBottom: 10,
    margin: 5,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: '#38373C',
    elevation: 3,
    height: 'auto',
  },
  image: {
    alignSelf: 'center',
    width: '100%',
    height: 114,
    borderRadius: 20,
  },
  date: {
    color: '#F5C89B',
    textAlign: 'center',
    fontSize: 22,
    paddingTop: 4,
  },
  description: {
    color: '#fff',
    fontSize: 22,
    wordWrap: 'wrap',
  },
});

export default App;
