import React from 'react';
import { ScrollView, View, Text, TextProps } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

// Цвета
import { ayuDark } from "../../colors/colors";
const { primary1, primary2, accent1, accent_gr1, accent_gr2 } = ayuDark;

const Tab = createBottomTabNavigator();

export default function ProfileScreen() {
    return (
        <View>
        </View>
    );
}