import { View, Text } from 'react-native';

import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from '@expo/vector-icons/Ionicons';

const RootStack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

/* 
 Используем только HomeScreen т.к. это главный экран и мы начинаем с него 
 На самом HomeScreen, etc..  TabNavigation
*/

import HelpScreen from './screens/HelpScreen';
import HomeScreen from './screens/HomeScreen';
import NewsScreen from './screens/NewsScreen';
import EventScreen from './screens/EventScreen';
import ProfileScreen from './screens/ProfileScreen';

// Цвета
import { ayuDark } from "../colors/colors";
const { primary1, primary2, accent1, accent_gr1, accent_gr2 } = ayuDark;

function Home() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Home!</Text>
    </View>
  );
}

export default function MyStack() {
  return (
    <>
      {/* 
      <RootStack.Navigator>
      <RootStack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Welcome' }}
        />
        </RootStack.Navigator> */}

      <Tab.Navigator initialRouteName='Home' screenOptions={{ headerShown: false, tabBarStyle: {backgroundColor: primary2, borderTopWidth: 0,}}}>
        <Tab.Screen name="Help" component={HelpScreen} />
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Events" component={EventScreen} />
        <Tab.Screen name="News" component={NewsScreen} />
        {/* <Tab.Screen name="Profile" component={ProfileScreen}/> */}
      </Tab.Navigator>
    </>

  );
};

/*

// You can import Ionicons from @expo/vector-icons/Ionicons if you use Expo or
// react-native-vector-icons/Ionicons otherwise.
import Ionicons from 'react-native-vector-icons/Ionicons';

// (...)

export default function App() {
    return (
        <NavigationContainer>
            <Tab.Navigator
                screenOptions={({ route }) => ({
                    tabBarIcon: ({
                        focused,
                        color,
                        size,
                    }) => {
                        let iconName;

                        if (route.name === 'Home') {
                            iconName = focused
                                ? 'ios-information-circle'
                                : 'ios-information-circle-outline';
                        } else if (
                            route.name === 'Settings'
                        ) {
                            iconName = focused
                                ? 'ios-list'
                                : 'ios-list-outline';
                        }

                        // You can return any component that you like here!
                        return (
                            <Ionicons
                                name={iconName}
                                size={size}
                                color={color}
                            />
                        );
                    },
                    tabBarActiveTintColor: 'tomato',
                    tabBarInactiveTintColor: 'gray',
                })}
            >
                <Tab.Screen
                    name="Home"
                    component={HomeScreen}
                />
                <Tab.Screen
                    name="Settings"
                    component={SettingsScreen}
                />
            </Tab.Navigator>
        </NavigationContainer>
    );
}

*/